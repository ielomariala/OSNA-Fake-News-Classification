# CS579 - Online social network analysis - IIT - Spring 2022 

# Fake News Clasification

## Team Members
- Ismail Elomari Alaoui   A20497221

- Reda Chaguer            A20497223


## Project description
[Project description](./doc/S22___CS_579___Project_II%20(Project%20Description).pdf)
[Best Model Weights](https://drive.google.com/file/d/1M0LRj7Z1eyCPXVm4OOGbt-fdBRwO5xkz/view?usp=sharing)

## Repositry Tree

- [data](./data/) : contains training and testing csv files.

- [doc](./doc/) : Contains documentation (project description, report, presentation, ...)

- [src](./src/) : Source code (Python scripts and notebooks).

- [res](./res/) : Contains the [submission sample](./res/sample_submission.csv) and our final result [submission](./res/submission.csv).